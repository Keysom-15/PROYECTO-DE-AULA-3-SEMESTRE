import SOFTWELL.BaseDeDatos;
import SOFTWELL.GestorArchivos;
import SOFTWELL.Producto;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Main {

    private static  Color COLOR_DORADO = new Color(212, 175, 55);
    private static  Font FUENTE_TITULO = new Font("Georgia", Font.BOLD, 30);
    private static  Font FUENTE_BOTON = new Font("Georgia", Font.BOLD, 18);

    private static JFrame ventana;
    private static JPanel panelActual;

    static class FondoPanel extends JPanel {
        private BufferedImage img;
        public FondoPanel(String ruta) {
            try {
                img = ImageIO.read(getClass().getResource(ruta));
            } catch (IOException | IllegalArgumentException e) {
                System.err.println("No se pudo cargar la imagen: " + ruta);
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (img != null) {
               
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::iniciar);
    }

    private static void iniciar() {
        ventana = new JFrame("SOFTWELL ");
        ventana.setExtendedState(JFrame.MAXIMIZED_BOTH);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mostrarPanelInicio();
        ventana.setVisible(true);
         // Cargar productos desde el archivo al iniciar
    try {
        GestorArchivos.cargarProductos("productos.txt");
    } 
    catch (IOException e) {
        System.err.println("Error al cargar productos: " + e.getMessage());
    }

    mostrarPanelInicio(); // Ya existente
    ventana.setVisible(true);
}
    

    private static void mostrarPanelInicio() {
        panelActual = new FondoPanel("/Imagen.png");
        panelActual.setLayout(new BorderLayout());
        panelActual.setBorder(BorderFactory.createLineBorder(COLOR_DORADO, 3)); 

        JLabel titulo = new JLabel("BIENVENIDO", SwingConstants.LEFT);
        titulo.setFont(FUENTE_TITULO);
        titulo.setForeground(COLOR_DORADO);
        titulo.setBorder(BorderFactory.createEmptyBorder(50, 20, 20, 20));
        panelActual.add(titulo, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel();
        panelBotones.setOpaque(false);
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));

        JButton btnLogin = crearBoton("Iniciar Sesión");
        JButton btnRegistro = crearBoton("Registrarse");
        JButton btnSalir = crearBoton("Salir");

        panelBotones.add(btnLogin);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 30)));
        panelBotones.add(btnRegistro);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 20)));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createVerticalGlue());

        btnLogin.addActionListener(e -> mostrarPanelLogin());
        btnRegistro.addActionListener(e -> mostrarPanelRegistro());
        btnSalir.addActionListener(e -> System.exit(0));

        panelActual.add(panelBotones, BorderLayout.WEST);

        ventana.setContentPane(panelActual);
        ventana.revalidate();
        ventana.repaint();
    }

    private static void mostrarPanelLogin() {
        panelActual = new FondoPanel("/Imagen.png");
        panelActual.setLayout(null);
        panelActual.setBorder(BorderFactory.createLineBorder(COLOR_DORADO, 3)); 

        JLabel lblUser = new JLabel("Usuario:");
        lblUser.setBounds(200, 100, 100, 30);
        JTextField txtUser = new JTextField();
        txtUser.setBounds(310, 100, 200, 30);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(200, 150, 100, 30);
        JPasswordField txtPass = new JPasswordField();
        txtPass.setBounds(310, 150, 200, 30);

        JButton btnIngresar = crearBoton("Ingresar");
        btnIngresar.setBounds(250, 220, 120, 40);
        JButton btnVolver = crearBoton("Volver");
        btnVolver.setBounds(390, 220, 120, 40);

        btnIngresar.addActionListener(e -> {
            String u = txtUser.getText();
            String c = new String(txtPass.getPassword());
            if (BaseDeDatos.autenticarAdmin(u, c)) mostrarPanelAdmin();
            else if (BaseDeDatos.autenticarCliente(u, c)) mostrarPanelCliente();
            else JOptionPane.showMessageDialog(ventana, "Credenciales incorrectas.");
        });
        btnVolver.addActionListener(e -> mostrarPanelInicio());

        panelActual.add(lblUser);
        panelActual.add(txtUser);
        panelActual.add(lblPass);
        panelActual.add(txtPass);
        panelActual.add(btnIngresar);
        panelActual.add(btnVolver);

        ventana.setContentPane(panelActual);
        ventana.revalidate();
        ventana.repaint();
    }

    private static void mostrarPanelRegistro() {
        panelActual = new FondoPanel("/Imagen.png");
        panelActual.setLayout(null);
        panelActual.setBorder(BorderFactory.createLineBorder(COLOR_DORADO, 3)); 

        JLabel lblTipo = new JLabel("Tipo de Usuario:");
        lblTipo.setBounds(200, 80, 120, 30);
        String[] opciones = {"Administrador", "Cliente"};
        JComboBox<String> comboTipo = new JComboBox<>(opciones);
        comboTipo.setBounds(330, 80, 150, 30);

        JLabel lblUser = new JLabel("Usuario:");
        lblUser.setBounds(200, 130, 100, 30);
        JTextField txtUser = new JTextField();
        txtUser.setBounds(310, 130, 200, 30);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(200, 180, 100, 30);
        JPasswordField txtPass = new JPasswordField();
        txtPass.setBounds(310, 180, 200, 30);

        JButton btnRegistrar = crearBoton("Registrar");
        btnRegistrar.setBounds(250, 250, 120, 40);
        JButton btnVolver = crearBoton("Volver");
        btnVolver.setBounds(390, 250, 120, 40);

        btnRegistrar.addActionListener(e -> {
            String u = txtUser.getText();
            String c = new String(txtPass.getPassword());
            if (u.isEmpty() || c.isEmpty()) {
                JOptionPane.showMessageDialog(ventana, "Datos inválidos."); return;
            }
            boolean esAdmin = comboTipo.getSelectedIndex() == 0;
            if (BaseDeDatos.existeAdmin(u) || BaseDeDatos.existeCliente(u))
                JOptionPane.showMessageDialog(ventana, "El usuario ya existe.");
            else {
                if (esAdmin) BaseDeDatos.addAdmin(u, c);
                else          BaseDeDatos.addCliente(u, c);
                JOptionPane.showMessageDialog(ventana, (esAdmin ? "Administrador" : "Cliente") + " registrado.");
                mostrarPanelInicio();
            }
        });
        btnVolver.addActionListener(e -> mostrarPanelInicio());

        panelActual.add(lblTipo);
        panelActual.add(comboTipo);
        panelActual.add(lblUser);
        panelActual.add(txtUser);
        panelActual.add(lblPass);
        panelActual.add(txtPass);
        panelActual.add(btnRegistrar);
        panelActual.add(btnVolver);

        ventana.setContentPane(panelActual);
        ventana.revalidate();
        ventana.repaint();
    }

    private static void mostrarPanelAdmin() {
        panelActual = new FondoPanel("/Imagen.png");
        panelActual.setLayout(null);
        panelActual.setBorder(BorderFactory.createLineBorder(COLOR_DORADO, 3));

        JLabel titulo = new JLabel("MENÚ ADMINISTRADOR", SwingConstants.CENTER);
        titulo.setBounds(100, 20, 400, 30);
        titulo.setFont(FUENTE_TITULO);
        titulo.setForeground(COLOR_DORADO);
        panelActual.add(titulo);
        

        JButton agregar = crearBoton("Agregar producto");
        agregar.setBounds(200, 80, 200, 40);
        JButton buscar = crearBoton("Buscar producto");
        buscar.setBounds(200, 230, 200, 40);
        JButton eliminar = crearBoton("Eliminar producto");
        eliminar.setBounds(200, 180, 200, 40);
        JButton listar = crearBoton("Listar productos");
        listar.setBounds(200, 130, 200, 40);
        JButton cerrar = crearBoton("Cerrar sesión");
        cerrar.setBounds(200, 280, 200, 40);
        


        agregar.addActionListener(e -> {
    String nombre = JOptionPane.showInputDialog(ventana, "Nombre del producto:");
    if (nombre != null && !nombre.trim().isEmpty()) {
        // Pedir el precio del producto
        double precio = -1;
        while (precio < 0) {
            String precioStr = JOptionPane.showInputDialog(ventana, "Ingrese el precio del producto:");
            if (precioStr != null && !precioStr.trim().isEmpty()) {
                try {
                    precio = Double.parseDouble(precioStr);
                    if (precio < 0) {
                        JOptionPane.showMessageDialog(ventana, "El precio debe ser positivo.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(ventana, "Entrada inválida. Intente con un número decimal.");
                }
            } else {
                JOptionPane.showMessageDialog(ventana, "El precio no puede estar vacío.");
            }
        }

        // Crear el producto con el nombre, ID y precio
        int id = Producto.generarId();
        Producto p = new Producto(nombre.toUpperCase(), id, precio);

        // Agregar el producto a la base de datos
        BaseDeDatos.addProducto(p);
        JOptionPane.showMessageDialog(ventana, "Producto agregado correctamente"+ "\n"+
                "Nombre:"+nombre + "\n"+
                "ID: " + id +"\n"+
                "Precio:"+"$"+precio+ "\n");
    } else {
        JOptionPane.showMessageDialog(ventana, "El nombre del producto no puede estar vacío.");
    }
});

        buscar.addActionListener(e -> {
    String[] opciones = {"Por ID", "Por nombre"};
    int eleccion = JOptionPane.showOptionDialog(
        ventana,
        "¿Cómo desea buscar el producto?",
        "Buscar producto",
        JOptionPane.DEFAULT_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        opciones,
        opciones[0]
    );

    if (eleccion == 0) { // Buscar por ID
        String input = JOptionPane.showInputDialog(ventana, "Ingrese ID del producto:");
        try {
            int id = Integer.parseInt(input);
            Producto p = BaseDeDatos.buscarPorId(id);
            if (p != null) {
                JOptionPane.showMessageDialog(ventana, "ID: " + p.getId() + "\nNombre: " + p.getNombre() + "\nPrecio: $" + p.getPrecio());
            } else {
                JOptionPane.showMessageDialog(ventana, "Producto no encontrado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(ventana, "ID inválido.");
        }
    } else if (eleccion == 1) { // Buscar por nombre
        String nombre = JOptionPane.showInputDialog(ventana, "Ingrese nombre del producto:");
        StringBuilder sb = new StringBuilder();
        for (Producto p : BaseDeDatos.getAllProductos()) {
            if (p.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                sb.append("ID: ").append(p.getId()).append("\n")
                  .append("Nombre: ").append(p.getNombre()).append("\n")
                  .append("Precio: $").append(p.getPrecio()).append("\n\n");
            }
        }
        if (sb.length() == 0) sb.append("No se encontraron coincidencias.");
        JOptionPane.showMessageDialog(ventana, sb.toString());
    }
});

        eliminar.addActionListener(e -> {
            String idStr = JOptionPane.showInputDialog(ventana, "ID del producto a eliminar:");
            try {
                int id = Integer.parseInt(idStr);
                if (BaseDeDatos.removeProducto(id)) {
                    JOptionPane.showMessageDialog(ventana, "Producto eliminado.");
                } else {
                    JOptionPane.showMessageDialog(ventana, "No encontrado.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, "ID inválido.");
            }
        });

          listar.addActionListener(e -> {
               StringBuilder sb = new StringBuilder();
                 for (Producto p : BaseDeDatos.getAllProductos()) {
                     sb.append("ID: ").append(p.getId())
                       .append("\n").append(p.getNombre())
                       .append("\n").append(p.getPrecio())
                       .append("\n")
                       .append("\n");
                     
    }
    if (sb.length() == 0) sb.append("No hay productos.");
    JOptionPane.showMessageDialog(ventana, sb.toString());
});


        cerrar.addActionListener(e -> mostrarPanelInicio());

        panelActual.add(agregar);
        panelActual.add(buscar);
        panelActual.add(eliminar);
        panelActual.add(listar);
        panelActual.add(cerrar);

        ventana.setContentPane(panelActual);
        ventana.revalidate();
        ventana.repaint();
    }

    private static void mostrarPanelCliente() {
        panelActual = new FondoPanel("/Imagen.png");
        panelActual.setLayout(null);
        panelActual.setBorder(BorderFactory.createLineBorder(COLOR_DORADO, 3)); 

        JLabel titulo = new JLabel("MENÚ CLIENTE", SwingConstants.CENTER);
        titulo.setBounds(100, 20, 400, 30);
        titulo.setFont(FUENTE_TITULO);
        titulo.setForeground(COLOR_DORADO);
        panelActual.add(titulo);

        JButton listar = crearBoton("Listar productos");
        listar.setBounds(200, 80, 200, 40);
        JButton buscar = crearBoton("Buscar producto");
        buscar.setBounds(200, 130, 200, 40);
        JButton cerrar = crearBoton("Cerrar sesión");
        cerrar.setBounds(200, 180, 200, 40);

        listar.addActionListener(e -> {
    StringBuilder sb = new StringBuilder();
    for (Producto p : BaseDeDatos.getAllProductos()) {
        sb.append("Nombre: ").append(p.getNombre()).append("\n");
        sb.append("Precio: $").append(p.getPrecio()).append("\n\n");
    }
    if (sb.length() == 0) {
        sb.append("No hay productos.");
    }
    JOptionPane.showMessageDialog(ventana, sb.toString());
});


        buscar.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(ventana, "Buscar nombre:");
            StringBuilder sb = new StringBuilder();
            for (Producto p : BaseDeDatos.getAllProductos()) {
                if (p.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                    sb.append("Nombre: ").append(p.getNombre()).append("\n").append("Precio: ").append(p.getPrecio()).append("\n")
                            .append("\n");
                }
            }
            if (sb.length() == 0) sb.append("No se encontraron coincidencias.");
            JOptionPane.showMessageDialog(ventana, sb.toString());
        });

        cerrar.addActionListener(e -> mostrarPanelInicio());

        panelActual.add(listar);
        panelActual.add(buscar);
        panelActual.add(cerrar);

        ventana.setContentPane(panelActual);
        ventana.revalidate();
        ventana.repaint();
    }

    private static JButton crearBoton(String texto) {
        JButton b = new JButton(texto);
        b.setMaximumSize(new Dimension(220, 60));
        b.setPreferredSize(new Dimension(220, 60));
        b.setFont(FUENTE_BOTON);
        b.setBackground(COLOR_DORADO);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder());
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
