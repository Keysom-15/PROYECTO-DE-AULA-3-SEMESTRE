package SOFTWELL;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class GestorArchivos {
    public static void guardarProductos(String ruta) throws IOException {
    try (BufferedWriter w = new BufferedWriter(new FileWriter(ruta))) {
        for (Producto p : BaseDeDatos.getAllProductos()) {
            w.write(p.getId() + "," + p.getNombre() + "," + p.getPrecio()); // <--- añadimos el precio
            w.newLine();
        }
    }
}


    public static void cargarProductos(String ruta) throws IOException {
    try (BufferedReader r = new BufferedReader(new FileReader(ruta))) {
        String linea;
        int maxId = 0;
        while ((linea = r.readLine()) != null) {
            String[] d = linea.split(",", 3); // ahora esperamos 3 elementos
            if (d.length == 3) {
                int id = Integer.parseInt(d[0]);
                String nombre = d[1];
                double precio = Double.parseDouble(d[2]); // convertimos a double
                BaseDeDatos.addProducto(new Producto(nombre, id, precio));
                if (id > maxId) maxId = id;
            }
        }
    }

    }
}