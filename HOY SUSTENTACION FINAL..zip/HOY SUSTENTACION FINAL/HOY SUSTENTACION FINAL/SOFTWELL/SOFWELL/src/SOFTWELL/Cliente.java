package SOFTWELL;

import java.util.Scanner;

public class Cliente {
    public boolean autenticarCliente(String usuario, String clave) {
        return BaseDeDatos.autenticarCliente(usuario, clave);
    }

    public void listarProductos() {
        if (BaseDeDatos.getAllProductos().isEmpty()) {
            System.out.println("No hay productos disponibles.");
        } else {
            for (Producto p : BaseDeDatos.getAllProductos()) {
                System.out.println(p);
            }
        }
    }

    public void buscarProducto(Scanner scanner) {
        System.out.print("Nombre (o parte) del producto: ");
        String texto = scanner.nextLine().toLowerCase();
        boolean encontrado = false;
        for (Producto p : BaseDeDatos.getAllProductos()) {
            if (p.getNombre().toLowerCase().contains(texto)) {
                System.out.println("Encontrado: " + p);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontró producto que contenga '" + texto + "'.");
        }
    }
}
