package SOFTWELL;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class BaseDeDatos {
    private static Map<Integer, Producto> producto = new HashMap<>();
    private static Map<String, String> cliente = new HashMap<>();
    private static Map<String, String> administrador = new HashMap<>();

    public static void addProducto(Producto p) {
        producto.put(p.getId(), p);
    }

    public static boolean removeProducto(int id) {
        return producto.remove(id) != null;
    }

    public static Collection<Producto> getAllProductos() {
        return producto.values();
    }

    public static boolean autenticarCliente(String u, String c) {
        return c.equals(cliente.get(u));
    }

    public static boolean autenticarAdmin(String u, String c) {
        return c.equals(administrador.get(u));
    }

    public static void addCliente(String u, String c) {
        cliente.put(u, c);
    }

    public static void addAdmin(String u, String c) {
        administrador.put(u, c);
    }

    public static boolean existeCliente(String u) {
        return cliente.containsKey(u);
    }

    public static boolean existeAdmin(String u) {
        return administrador.containsKey(u);
    }
    
    
    public static Producto buscarPorId(int id) {
    return producto.get(id); // Accede directamente al mapa por ID
}


}



